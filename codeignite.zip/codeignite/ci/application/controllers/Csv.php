<?php
class Csv extends CI_Controller
{
	// private $dbhost = 'localhost';
	//  private $dbuser = 'root';
	//  private $dbpass = '';		
	 // private $dbname = 'csvdb';
	public function __construct()
  {
   parent::__construct();
   $this->load->model("Csv_model");
    // error_reporting(E_ALL & ~E_NOTICE);
  }
	public function getcsv()
		{
			//$conn = mysqli_connect($this->dbhost,$this->dbuser,$this->dbpass,$this->dbname);

			/*if (mysqli_connect_errno())
				{
					echo "Failed to connect to MySQL: " . mysqli_connect_error();
				}*/

			// $listdbtables = array_column(mysqli_fetch_all($conn->query('SHOW TABLES')),0);
			//$listdbtables = array_column(mysqli_fetch_all($this->Csv_model->get_table_names()),0);
			// ($this->Csv_model->get_table_names());
			// $listdbtables = $this->Csv_model->get_table_names();
			$data['listdbtables'] = $this->Csv_model->get_table_names();
			
			 // $data['listdbtables']=$listdbtables;
				// print_r($data['tbs']);
			$this->load->view('index.php',$data);
		}
	public function getcsvdata()
	{
		$data['db_table']=$this->input->post('dbtable');
		$file_name=APPPATH."filecsv/".time().$_FILES['csvfile']['name'];
		move_uploaded_file ( $_FILES['csvfile']['tmp_name'] , $file_name );
		// $data['dbhost']=$this->dbhost;
		// $data['dbuser']=$this->dbuser;
		// $data['dbpass']=$this->dbpass;
		// $data['dbname']=$this->dbname;
		$data['result']=$this->Csv_model->get_column_names($_POST['dbtable']);
		$data['csv']=array_map("str_getcsv", file($file_name,FILE_SKIP_EMPTY_LINES));
		$data['file'] = fopen($file_name,"r");
		$this->load->view('getcsvdata.php',$data);
	}
	public function insertintodb()
	{
		/*$conn = mysqli_connect($this->dbhost,$this->dbuser,$this->dbpass,$this->dbname);

		if (mysqli_connect_errno())
			{
				$error['e1'] = "Failed to connect to MySQL: " . mysqli_connect_error();
			}*/


		$lengthofpost = count($this->input->post());
		$data = $this->input->post();
		$ss="";
		// print_r($data);
		for($k=0;$k<count(explode(";",$this->input->post('hh1')));$k++)
			{
				$s="(";
				for($i = 0; $i < $lengthofpost/2; $i++)
					{
						$arr=explode(";", $this->input->post("hh".$i));
						$s=$s."'".$arr[$k]."',";

					}
				$s=rtrim($s,",");
				$s=$s."),";
				$ss=$ss.$s;

			}
		$ss = rtrim($ss,",");
		$y="";
		for($j = $lengthofpost/2; $j < $lengthofpost; $j++)
			{
				$arrkey = array_keys($data)[$j];
				$y=$y."`".$data[$arrkey]."`,";
			}
		$y =  rtrim($y, ",");
		$kkk="insert into testcsv(".$y.") values".$ss;
		/*if(!mysqli_query($conn,$kkk))
			{
				$error['e2'] = mysqli_error($conn);
			}*/
		// $this->load->view("insert_errors.php",$error);
		$data['count']=$this->Csv_model->insert_values($kkk);
		// echo "done";
		$this->load->view("form_submission.php",$data);
	}
}