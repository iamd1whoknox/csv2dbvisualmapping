<?php
if(isset($e1))
echo $e1;
if(isset($e2))
echo $e2;
?>