<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Virtuos - Visual Data Mapping</a>
    </div>
  </div>
</nav>
<div class='container'>
<div class='jumbotron'>
<center>
<form action="insertintodb" method="post">
<?php

//$db_table = $_POST['dbtable'];

//$csv = array_map("str_getcsv", file("semicolon.csv",FILE_SKIP_EMPTY_LINES));
$keys = array_shift($csv);
foreach ($csv as $i=>$row) {
    $csv[$i] = array_combine($keys, $row);
    
}
$csvheads = explode(";", $keys[0]);
$csvheadslen=sizeof($csvheads);
// for($i = 0; $i < $csvheadslen; $i++)
// {
// 	if($i>0)
// 	{
// 		break;
// 	}
// 	//echo $csvheads[$i];
// 	$firstofcsv = explode(";",$csv[$i][$keys[0]]);
// 	$firstofcsvlen = sizeof($firstofcsv);
// 	for($i = 0; $i < $firstofcsvlen; $i++)
// 	{
// 		echo "<input type='hidden' value='$firstofcsv[$i]' name='val".$i."'>";
// 	}
// 	echo "<br>";

// }

//$file = fopen("semicolon.csv","r");
$arr=array();
$c=0;
while(! feof($file))
  {
  $arrr=fgetcsv($file);
  $x=explode(";", $arrr[0]);
  $arr[$c]=$x;
  $c++;
  }
  //$s="";
  //echo $arr[0][0];
  //echo $arr[0][0];
for($j = 0; $j < $csvheadslen; $j++)
{
	$s="";
	for($i = 0;$i < $c; $i++)
	{
    if(!empty($arr[$i][$j]))
 		$s=$s.$arr[$i][$j].";";	

	}
	echo "<input type='hidden' value='".$s."' name='hh".$j."'>";
	// echo $s;
 }
// echo "<br><br><br><br><br><br><br>";

// echo $csv[$i][$keys[0]];

/*$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}*/
echo '<style>td{padding:10px;}</style><table><tr><th>CSV Fields</th><th>Database Fields</th>';
/*$result = mysqli_query($conn,"SHOW COLUMNS FROM $db_table");
for($i=0;$i<$result->num_rows;$i++){
$result = mysqli_query($conn,"SHOW COLUMNS FROM $db_table");*/
//for($i=0;$i<count($result);$i++){
for($i=0;$i<$csvheadslen;$i++){
?>
<tr><td><?php echo $csvheads[$i]; ?></td><td><select name=<?php echo "f".$i; ?> class='form-control'>
<?php
// if (mysqli_num_rows($result) > 0) {
    foreach($result as $value) {
      ?>
        
        <option value=<?php echo $value; ?> ><?php echo $value; ?></option>
<?php        
    }
 

?>
</select></td></tr>
<?php
}
echo "</table><br><input type='submit' value='Insert Mapped Items' class='btn btn-primary'></form>";
// echo $file_name;
?>
</center>
</div>
</div>
</body>
</html>