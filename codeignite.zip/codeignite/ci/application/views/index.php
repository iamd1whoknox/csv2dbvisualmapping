
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Virtuos - Visual Data Mapping</a>
    </div>
  </div>
</nav>
<div class='container'>
<div class='jumbotron'>
<div class='row'>
<div class='col-lg-4'></div>
<div class='col-lg-4'>
<form action='getcsvdata' method='post' enctype='multipart/form-data'>
<div class="form-group">
<input type='file' name='csvfile' class="form-control">
</div>
<br>
<div class="form-group">
<select name='dbtable' class="form-control">
	<option disabled>--SELECT--</option>
	<?php
		foreach ($listdbtables as $key => $value) 
		{
			echo "<option value=$value>$value</option>";

		}
	 ?>
</select>
</div>
<input type='submit' value='Submit' class='btn btn-primary'>	
</form>
</div>
<div class='col-lg-4'></div>
</div>
</div>
</div>
</body>
</html>