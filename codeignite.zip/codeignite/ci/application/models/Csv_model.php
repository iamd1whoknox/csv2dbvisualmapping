<?php
class Csv_model extends CI_Model
{
	// public function __construct()
	// {
	// 	$this->load->database();
	// }
	public function get_table_names()
	{
		//$tables = $this->db->query("SHOW TABLES");
		$tables=$this->db->list_tables();
		// print_r($tables->row_array());
		return $tables;
	}
	public function get_column_names($table)
	{
		$columns=$this->db->list_fields($table);
		return $columns;
	}
	public function insert_values($qry)
	{
		$this->db->query($qry);
		// echo $this->db->affected_rows();
		return $this->db->affected_rows();
		// if($this->db->affected_rows() == 0)
		// {

		// }
	}
}
